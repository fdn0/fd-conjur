**Headers**

| Field         | Description         | Example                     |
|---------------|---------------------|-----------------------------|
| Authorization | Conjur access token | Token token="eyJkYX...Rhb=" |
