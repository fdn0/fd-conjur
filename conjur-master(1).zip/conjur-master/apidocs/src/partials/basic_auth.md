Your HTTP/REST client probably provides HTTP basic authentication support. For
example, `curl` and all of the Conjur client libraries provide this.

[auth]: https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication#Basic_authentication_scheme
