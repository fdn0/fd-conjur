If the parameter `count` is `true`, returns only the number of items in the
list.
