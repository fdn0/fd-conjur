If a `limit` is given, returns no more than that number of results. Providing an
`offset` skips a number of resources before returning the rest. In addition,
providing an `offset` will give `limit` a default value of 10 if none other is
provided. These two parameters can be combined to page through results.
