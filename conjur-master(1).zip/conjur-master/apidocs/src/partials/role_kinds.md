#### Kinds of roles

|Kind  |Description                                                      |
|------|-----------------------------------------------------------------|
|User  |one unique wonderful human                                       |
|Host  |a single logical machine (in the broad sense, not just physical) |
|Layer |a collection of hosts that have the same privileges              |
|Group |a collection of users and groups that have the same privileges   |
|Policy|a role which owns of a set of related objects                    |
