If a `kind` query parameter is given, narrows results to only resources of that
kind.
