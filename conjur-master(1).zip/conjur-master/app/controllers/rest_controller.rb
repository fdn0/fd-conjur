# frozen_string_literal: true

class RestController < ApplicationController
  include CurrentUser
end
