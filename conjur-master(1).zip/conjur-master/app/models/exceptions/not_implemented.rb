# frozen_string_literal: true

module Exceptions
  class NotImplemented < RuntimeError
  end
end
