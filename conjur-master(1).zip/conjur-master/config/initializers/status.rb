# frozen_string_literal: true

ENV["POSSUM_VERSION_APPLIANCE"] = File.read(File.expand_path("../../VERSION_APPLIANCE", File.dirname(__FILE__)))
