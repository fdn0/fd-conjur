require 'cucumber/rails'
require 'rack/test'
require 'json_spec/cucumber'

def app
  Rails.application
end
