# frozen_string_literal: true

module ConjurAudit
  class ApplicationController < ActionController::Base
  end
end
