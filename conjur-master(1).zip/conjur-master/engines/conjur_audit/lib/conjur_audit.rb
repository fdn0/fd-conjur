# frozen_string_literal: true

require "conjur_audit/engine"

module ConjurAudit
end
