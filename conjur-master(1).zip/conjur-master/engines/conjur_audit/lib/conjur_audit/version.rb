# frozen_string_literal: true

module ConjurAudit
  VERSION = "0.0.1"
end
