#!/bin/bash -e

heroku run conjurctl db migrate

